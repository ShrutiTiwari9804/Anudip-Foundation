import java.sql.*;
import java.util.Scanner;

public class Veterinary {
    private static final String url = "jdbc:mysql://localhost:3306/veterinary_System";
    private static final String username = "root";
    private static final String password = "root";

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, username, password);
            Scanner scanner = new Scanner(System.in);
            System.out.println("Connection established successfully");

            while (true) {
                System.out.println("\nWelcome to Veterinary Clinic");
                System.out.println("1. Add new patients");
                System.out.println("2. Schedule Appointment");
                System.out.println("3. View Patients");
                System.out.println("4. View Appointments Records");
                System.out.println("5. View Doctors");
                System.out.println("6. Exit");

                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        addPatients(con, scanner);
                        break;
                    case 2:
                        scheduleAppointment(con, scanner);
                        break;
                    case 3:
                        viewPatients(con);
                        break;
                    case 4:
                        viewAppointments(con);
                        break;
                    case 5:
                        viewDoctors(con);
                        break;
                    case 6 :
                        System.out.println("Thank you for visiting. Goodbye!");
                        con.close();
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void addPatients(Connection con, Scanner scanner) {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Species: ");
        String species = scanner.nextLine();
        System.out.print("Breed: ");
        String breed = scanner.nextLine();
        System.out.print("Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        String query = "INSERT INTO patients (name, species, breed, age) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, species);
            pstmt.setString(3, breed);
            pstmt.setInt(4, age);
            pstmt.executeUpdate();
            System.out.println("Patient added successfully");
        } catch (SQLException e) {
            System.out.println("Error adding patient: " + e.getMessage());
        }
    }

    public static void scheduleAppointment(Connection con, Scanner scanner) {
        System.out.print("Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Date (YYYY-MM-DD): ");
        String dateInput = scanner.nextLine().trim();
        java.sql.Date appointmentDate;
        try {
            appointmentDate = java.sql.Date.valueOf(dateInput);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid date format.");
            return;
        }

        System.out.print("Time (HH:MM:SS): ");
        String timeInput = scanner.nextLine().trim();
        java.sql.Time appointmentTime;
        try {
            appointmentTime = java.sql.Time.valueOf(timeInput);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid time format.");
            return;
        }

        System.out.print("Reason: ");
        String reason = scanner.nextLine();
        System.out.println("Enter Status (Scheduled, Completed, Canceled): ");
        String status = scanner.nextLine();

        String query = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason_for_appointment, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setInt(1, patientId);
            pstmt.setInt(2, doctorId);
            pstmt.setDate(3, appointmentDate);
            pstmt.setTime(4, appointmentTime);
            pstmt.setString(5, reason);
            pstmt.setString(6, status);
            pstmt.executeUpdate();
            System.out.println("Appointment scheduled successfully");
        } catch (SQLException e) {
            System.out.println("Error scheduling appointment: " + e.getMessage());
        }
    }

    public static void viewPatients(Connection con) {
        String query = "SELECT patient_id, name, species, breed, age FROM patients";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\nPatient Records:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("patient_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Species: " + rs.getString("species"));
                System.out.println("Breed: " + rs.getString("breed"));
                System.out.println("Age: " + rs.getInt("age"));
                System.out.println("-------------------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching patients: " + e.getMessage());
        }
    }

    public static void viewAppointments(Connection con) {
        String query = "SELECT appointment_id, patient_id, doctor_id, appointment_date, appointment_time, reason_for_appointment, status FROM appointments";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\nAppointment Records:");
            while (rs.next()) {
                System.out.println("Appointment ID: " + rs.getInt("appointment_id"));
                System.out.println("Patient ID: " + rs.getInt("patient_id"));
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Date: " + rs.getDate("appointment_date"));
                System.out.println("Time: " + rs.getTime("appointment_time"));
                System.out.println("Reason: " + rs.getString("reason_for_appointment"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("-----------------------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching appointments: " + e.getMessage());
        }
    }

    public static void viewDoctors(Connection con) {
        String query = "SELECT doctor_id, name, specialization, contact FROM doctors";
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            System.out.println("\nDoctor Records:");
            while (rs.next()) {
                System.out.println("Doctor ID: " + rs.getInt("doctor_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Specialization: " + rs.getString("specialization"));
                System.out.println("Contact: " + rs.getString("contact"));
                System.out.println("-----------------------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching doctors: " + e.getMessage());
        }
    }

}
/*
 
compile:-
cd "C:\Users\Saurabh\Desktop\java"

javac -cp "C:\Users\Saurabh\Downloads\mysql-connector-j-9.3.0\mysql-connector-j-9.3.0.jar" Veterinary.java
run:-
java -cp "C:\Users\Saurabh\Downloads\mysql-connector-j-9.3.0\mysql-connector-j-9.3.0.jar;." Veterinary
 */

